# My experience and further notes



Describe the steps you took, what you liked, disliked, why did you do X instead of Y and so on here.



## 00 - Setup:


- I started the project by creating and defining the folder structure, separating them by responsibilities, and integrating an __init__.py file into each folder (still considered good practice in a production environment).

- For project development, I chose to simulate a real pipeline for the AWS cloud environment, as I have greater practical experience, I can develop and think about the project delivering value faster, but the resources simulated here easily apply to Azure (AWS and AZURE solution architecture will be included in the documentation).

- To generate synthetic customer, transaction, and product data using Faker and PySpark, I created the Faker object outside of functions to avoid serialization issues in Spark, as well as defining explicit schemas to ensure consistency of data types, especially in fields like dates and numbers. I organized the files by modules and left them ready for use in the main file.

- Every change is tested in the Jupyter notebook to ensure the execution of the code and the data being generated, and the data is saved in bronze, silver and gold layers (In a productive scenario, the bronze folder simulates the Data Lake environment in an S3 bucket catalog, and the silver/gold folder, the Data Warehouse).It was also not possible to save the data in my local folders because my computer does not have the settings allowed yet and I do not have time to configure it, so, if necessary, I placed the preview actions on the notebook.

- I created two files within the utils folder: One for starting the Spark session (it is only necessary here because it is a local test, in the cloud, the session is started and managed by the tool itself, in this case, Glue) and another file for writing functions. This practice ensures that the code is easier to read, and also allows the use of generic functions, such as writing, in other modules.

- I added unit tests for business rules, mocking and simulating a scenario for the functions in isolation. I started building an integration test to test if the pipeline logic is correct (also mocking the scenarios). The tests ran successfully, but the first with 33% coverage, normally, in a real scenario and using Sonar (for example) the test coverage proportion must be greater than 75% or 80% depending on the criticality of the data.

- To correct syntaxes and help debug test error logs, I used claude.ia, which is a good option for Python codes and unit tests.

- I wrote the documentation in a simple way so that it could also be understood by the business team. The architecture diagrams are present in the "docs" file.


- In a real project, I would use a permission and security tool, such as AWS IAM and with more time, the ideal would be to configure execution logs using CloudWatch.

- I created a file to containerize the project, the image and ran it locally successfully. In the cloud, the image can be published on Amazon ECR (create repository, Docker authentication, tag and push) and orchestrate the container with ECS or AWS Fargate.


**Kafka + Spark Streaming**
This step was not developed due to lack of time and robust practical experience in production, but the flow would be:

- Upgrade the environment with Kafka, Zookeeper and Spark via Docker Compose, to facilitate local reproduction.

- Create a Kafka producer in Python that reads the file and publishes each record as JSON to a topic.

- Configure a consumer with Spark Structured Streaming, connecting to Kafka, deserializing records into DataFrames and converting fields to the correct types.







